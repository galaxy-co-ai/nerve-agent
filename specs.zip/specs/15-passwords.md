# Password Manager

## Overview

A built-in password manager for project-related credentials. API keys, service logins, client credentials—all encrypted, organized by project, and accessible when you need them.

## Philosophy

- **Project-organized** — Credentials grouped by where they're used
- **Zero-knowledge encryption** — We can't see your passwords
- **Quick access** — Autofill and copy without leaving Nerve Agent
- **Secure sharing** — Share credentials with clients safely

---

## Vault Structure

### Password Vault

```
PASSWORD VAULT                                        127 items
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

┌─ ORGANIZATION ────┐  ┌─ CREDENTIALS ─────────────────────────────┐
│                   │  │                                            │
│ 📁 By Project     │  │  Search: [                              ]  │
│   └ Results       │  │                                            │
│   └ Galaxy Co     │  │  RESULTS ROOFING                          │
│   └ QuickClaims   │  │  ──────────────────────────────────────── │
│                   │  │                                            │
│ 📁 By Category    │  │  🔑 Stripe Live Keys                       │
│   └ API Keys      │  │     API • Added 2 weeks ago               │
│   └ Services      │  │                                            │
│   └ Client Access │  │  🔑 Supabase Service Key                   │
│   └ Databases     │  │     API • Added 2 weeks ago               │
│                   │  │                                            │
│ 📁 Personal       │  │  🔑 Sentry Auth Token                      │
│   └ Development   │  │     API • Added 2 weeks ago               │
│   └ Services      │  │                                            │
│                   │  │  🔑 Vercel Access Token                    │
│ ─────────────────│  │     API • Added 1 month ago                │
│                   │  │                                            │
│ 🔐 Master Password│  │  🔑 Client CRM Login                       │
│    Last changed:  │  │     Login • From client                   │
│    30 days ago    │  │                                            │
│                   │  │  [Load More...]                            │
└───────────────────┘  └────────────────────────────────────────────┘
```

### Credential Detail

```
CREDENTIAL DETAIL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔑 Stripe Live Keys — Results Roofing
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Type:        API Key
Project:     Results Roofing
Category:    API Keys
Added:       January 15, 2026
Last used:   2 hours ago

FIELDS
──────────────────────────────────────────────────────────────────
Publishable Key:
┌─────────────────────────────────────────────────────────────────┐
│ pk_live_••••••••••••••••••••••••••••••••               [Copy]  │
└─────────────────────────────────────────────────────────────────┘

Secret Key:
┌─────────────────────────────────────────────────────────────────┐
│ sk_live_••••••••••••••••••••••••••••••••               [Copy]  │
└─────────────────────────────────────────────────────────────────┘

Webhook Secret:
┌─────────────────────────────────────────────────────────────────┐
│ whsec_••••••••••••••••••••••••••••••••                 [Copy]  │
└─────────────────────────────────────────────────────────────────┘

NOTES
──────────────────────────────────────────────────────────────────
Live keys for production. Test keys in separate entry.

LINKED
──────────────────────────────────────────────────────────────────
→ Environment Variable: STRIPE_SECRET_KEY
→ Integration: Stripe Payments

[Edit]  [Copy All]  [Delete]
```

---

## Credential Types

### API Keys

```
ADD API KEY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Name:        [Stripe Live Keys                     ]
Project:     [Results Roofing ▾]
Category:    [API Keys ▾]

FIELDS
──────────────────────────────────────────────────────────────────
+ Publishable Key    [pk_live_...                        ]
+ Secret Key         [sk_live_...                        ]
+ Webhook Secret     [whsec_...                          ]
[+ Add Field]

Link to Environment Variable:
☑️ STRIPE_SECRET_KEY → Secret Key
☑️ STRIPE_WEBHOOK_SECRET → Webhook Secret

Notes:
┌─────────────────────────────────────────────────────────────────┐
│ Live keys for production environment                             │
└─────────────────────────────────────────────────────────────────┘

[Save Credential]
```

### Login Credentials

```
ADD LOGIN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Name:        [Client CRM Access                    ]
Project:     [Results Roofing ▾]
Category:    [Client Access ▾]

Website:     [https://crm.resultsroofing.com       ]
Username:    [developer@resultsroofing.com         ]
Password:    [••••••••••••••••                     ] [Generate]

TOTP (2FA):  [                                     ] [Scan QR]

Notes:
┌─────────────────────────────────────────────────────────────────┐
│ Access provided by Tareq for API integration work                │
└─────────────────────────────────────────────────────────────────┘

[Save Credential]
```

### Database Credentials

```
ADD DATABASE CREDENTIAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Name:        [Production Database                  ]
Project:     [Results Roofing ▾]
Category:    [Databases ▾]

Connection Type: [PostgreSQL ▾]

Host:        [db.supabase.co                       ]
Port:        [5432                                 ]
Database:    [postgres                             ]
Username:    [postgres                             ]
Password:    [••••••••••••••••                     ]

Connection String (auto-generated):
┌─────────────────────────────────────────────────────────────────┐
│ postgresql://postgres:****@db.supabase.co:5432/postgres [Copy]  │
└─────────────────────────────────────────────────────────────────┘

[Save Credential]
```

---

## Security

### Encryption Model

```
SECURITY MODEL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ZERO-KNOWLEDGE ENCRYPTION
──────────────────────────────────────────────────────────────────
• All credentials encrypted client-side
• Master password never leaves your device
• We cannot decrypt your passwords
• AES-256-GCM encryption

HOW IT WORKS
──────────────────────────────────────────────────────────────────
1. Master password → Key derivation (Argon2id)
2. Derived key encrypts all credentials
3. Only encrypted data stored on server
4. Decryption happens in your browser

WHAT WE STORE
──────────────────────────────────────────────────────────────────
• Encrypted credential blobs
• Encrypted metadata (names, categories)
• Salt for key derivation
• Nothing readable without your master password
```

### Master Password

```
MASTER PASSWORD SETTINGS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Current Status: ✓ Set
Last Changed: 30 days ago

REQUIREMENTS
──────────────────────────────────────────────────────────────────
☑️ Minimum 12 characters
☑️ Mix of uppercase and lowercase
☑️ At least one number
☑️ At least one special character

SECURITY OPTIONS
──────────────────────────────────────────────────────────────────
Auto-lock after:     [15 minutes ▾]
Require on startup:  [✓]
Biometric unlock:    [✓] (if available)

[Change Master Password]

⚠️ If you forget your master password, we cannot recover it.
   Your credentials will be permanently inaccessible.
```

### Access Log

```
ACCESS LOG
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

RECENT ACCESS
──────────────────────────────────────────────────────────────────
Today 2:34 PM    Copied: Stripe Live Keys → Secret Key
Today 11:20 AM   Viewed: Supabase Service Key
Today 9:15 AM    Unlocked vault
Yesterday        Copied: Vercel Access Token
Yesterday        Added: Client CRM Login

SECURITY EVENTS
──────────────────────────────────────────────────────────────────
Jan 25           Master password changed
Jan 20           New device authorized
Jan 15           Vault created
```

---

## Quick Access

### Keyboard Shortcuts

```
PASSWORD SHORTCUTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cmd+Shift+P        Open password search
Cmd+Shift+C        Copy last used credential
Cmd+L              Lock vault

In credential view:
Cmd+C              Copy password/key
Cmd+U              Copy username
Cmd+O              Open website
```

### Quick Search

```
Cmd+Shift+P — PASSWORD SEARCH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

┌─────────────────────────────────────────────────────────────────┐
│ stripe                                                           │
└─────────────────────────────────────────────────────────────────┘

RESULTS
──────────────────────────────────────────────────────────────────
🔑 Stripe Live Keys — Results Roofing
   API Key • [Copy Secret] [Copy Publishable]

🔑 Stripe Test Keys — Results Roofing
   API Key • [Copy Secret] [Copy Publishable]

🔑 Stripe Keys — Galaxy Co
   API Key • [Copy Secret]

Enter to copy primary field • Tab to see options
```

---

## Password Generator

### Generator Options

```
PASSWORD GENERATOR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Generated:
┌─────────────────────────────────────────────────────────────────┐
│ kX9#mP2$vL5@nQ8&                                        [Copy]  │
└─────────────────────────────────────────────────────────────────┘

[Regenerate]

OPTIONS
──────────────────────────────────────────────────────────────────
Length:          [16        ] ◀━━━━━━━━━━━━━━━●━━━▶

Include:
☑️ Uppercase (A-Z)
☑️ Lowercase (a-z)
☑️ Numbers (0-9)
☑️ Symbols (!@#$%^&*)
☐ Ambiguous characters (0O1lI)

PRESETS
──────────────────────────────────────────────────────────────────
[Strong (16)]  [Very Strong (24)]  [PIN (6)]  [Passphrase]
```

### Passphrase Generator

```
PASSPHRASE GENERATOR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Generated:
┌─────────────────────────────────────────────────────────────────┐
│ correct-horse-battery-staple-47                         [Copy]  │
└─────────────────────────────────────────────────────────────────┘

[Regenerate]

OPTIONS
──────────────────────────────────────────────────────────────────
Words:           [4         ]
Separator:       [- (dash)  ▾]
Include number:  [✓]
Capitalize:      [☐]
```

---

## Sharing

### Secure Share

```
SHARE CREDENTIAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Credential: Staging Environment Access

Share with:
┌─────────────────────────────────────────────────────────────────┐
│ tareq@resultsroofing.com                                        │
└─────────────────────────────────────────────────────────────────┘

SHARE OPTIONS
──────────────────────────────────────────────────────────────────
Expires:         [7 days ▾]
View limit:      [1 view ▾]
Require password: [✓]
Share password:  [Auto-generate ▾]

WHAT'S SHARED
──────────────────────────────────────────────────────────────────
☑️ URL
☑️ Username
☑️ Password
☐ Notes

[Create Secure Link]
```

### Share Link

```
SECURE LINK CREATED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Link:
┌─────────────────────────────────────────────────────────────────┐
│ https://nerve.app/share/pwd/abc123xyz                   [Copy]  │
└─────────────────────────────────────────────────────────────────┘

Access Password:
┌─────────────────────────────────────────────────────────────────┐
│ coral-sunset-47                                         [Copy]  │
└─────────────────────────────────────────────────────────────────┘

Send both to the recipient separately for security.

Expires: February 4, 2026
Views remaining: 1

[Send via Email]  [Copy Both]
```

---

## Import/Export

### Import

```
IMPORT PASSWORDS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Import from:
○ 1Password export
○ Bitwarden export
○ LastPass export
○ Chrome passwords (CSV)
● Generic CSV

[Choose File]

IMPORT PREVIEW
──────────────────────────────────────────────────────────────────
Found 45 credentials

Map columns:
Name:     [Column A ▾]
URL:      [Column B ▾]
Username: [Column C ▾]
Password: [Column D ▾]
Notes:    [Column E ▾]

Assign to project: [None (Personal) ▾]

[Import 45 Credentials]
```

### Export

```
EXPORT PASSWORDS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ Warning: Export contains unencrypted passwords

Export format:
○ Encrypted backup (recommended)
● CSV (unencrypted)
○ JSON (unencrypted)

Include:
○ All credentials (127)
● Specific project: [Results Roofing ▾] (12)
○ Specific category: [Select...]

Confirm master password to export:
┌─────────────────────────────────────────────────────────────────┐
│ ••••••••••••                                                    │
└─────────────────────────────────────────────────────────────────┘

[Export]
```

---

## Data Model

```typescript
interface Credential {
  id: string
  name: string                    // Encrypted
  type: "API_KEY" | "LOGIN" | "DATABASE" | "OTHER"
  project?: Project
  category: CredentialCategory
  fields: EncryptedField[]        // All encrypted
  notes?: string                  // Encrypted
  url?: string                    // Encrypted
  linkedEnvVars: string[]
  createdAt: Date
  updatedAt: Date
  lastAccessedAt?: Date
}

interface EncryptedField {
  name: string                    // Encrypted
  value: string                   // Encrypted
  type: "TEXT" | "PASSWORD" | "TOTP"
}

interface CredentialShare {
  id: string
  credential: Credential
  recipientEmail?: string
  accessPassword: string          // Hashed
  expiresAt: Date
  viewLimit: number
  viewCount: number
  createdAt: Date
}
```

---

## Integrations

### Environment Variables
- Credentials link to env vars
- Auto-populate when setting up projects

### Terminal
- Credentials accessible for CLI commands
- Secure injection without exposure

### Agent Actions
- Agents can access credentials for setup
- API keys used during automation

### Projects
- Credentials organized by project
- Project deletion prompts credential review
